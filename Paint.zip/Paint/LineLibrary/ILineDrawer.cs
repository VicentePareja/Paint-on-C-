﻿namespace LineLibrary;

public interface ILineDrawer
{
    public void Draw(LineRequest lineRequest);
}