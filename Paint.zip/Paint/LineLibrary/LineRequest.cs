﻿using System.Drawing;

namespace LineLibrary;

public class LineRequest
{
    public int[,]? Matrix;
    public Point? Origin;
    public Point? Destiny;
}