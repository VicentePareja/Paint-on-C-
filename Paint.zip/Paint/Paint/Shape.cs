﻿namespace Paint;

public enum Shape
{
    Circle,
    Point,
    Line,
    Rectangle
}