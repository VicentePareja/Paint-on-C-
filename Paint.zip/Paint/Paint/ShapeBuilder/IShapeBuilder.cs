﻿namespace Paint;

public interface IShapeBuilder
{
    void Draw(ShapeRequest request);
}